# ALREADY-AAC PROTECTION + BLOCKED KEYWORDS
Anyone who nominates a person who is ALREADY an AAC is banned for 24 hours automatically (it shows in DEV panel > BANS with its reason and can be lifted there). The DEV is never banned when testing.
- The list starts with the 53 AACs read from your Creator Program sheet (rows whose type is "Another Axiom Creator" / "AA Creator"; Shooting Stars are NOT protected - they are who gets promoted). The server re-reads the sheet every 6 hours (`AAC_SHEET_URL` env overrides the address; the sheet must stay shared "anyone with the link can view"). If the sheet ever looks wrong the old list is kept and the panel shows why.
- Matching ignores capitals, spaces and punctuation and also checks the handle inside links, so "S K E W T", "skewt!!" and tiktok.com/@SKEWT are all caught.
- DEV panel > AAC LIST · WORDS: add a new AAC, press x to remove someone (use this if a short/common name like "Polar" or "how" ever causes a false ban), sync now, and edit BLOCKED KEYWORDS (names, handles, titles and chat containing them are rejected).
- Protected people already on the board are removed from it when the list loads. A warning under the nominate form tells visitors about the ban.

# SECURITY (read this before releasing)
Principle: the browser is never trusted. A visitor can open dev tools and change what THEIR page shows, but whatever they edit, forge or script cannot change other visitors' pages, your data or your admin.
**Do these 3 things on Render > Environment:**
1. `ADMIN_KEY` = a long random password (16+ characters). WITHOUT it the admin password is the built-in one that lives in this repo's code - anyone who can read the repo could try to crack it. The DEV panel > DATA & BACKUP > SECURITY CHECK shows a warning until this is set.
2. `S3_*` cloud settings (see below) so updates never wipe data.
3. Leave `API_BASE` empty (the site and API are the same server). Only set `ALLOWED_ORIGINS` (comma list) if you host the page somewhere else on purpose.
**What the server now enforces:** all visitor text is cleaned (no HTML, hidden or direction-spoofing characters); session IDs and keys are format-checked and the server's own objects are frozen against prototype tricks; the visitor's REAL address is used (forged X-Forwarded-For / CF-Connecting-IP no longer dodge limits or bans); per-visitor and per-network caps on new sessions, nominations/nods, chat speed and live connections; strict Content-Security-Policy (no inline or foreign scripts can run), anti-clickjacking, nosniff, HSTS, COOP/CORP; uploads are verified by their real bytes and served in a sandbox; CORS only for your own domain; admin login is slowed and locked after repeated failures, and the browser only ever holds an 8-hour token, never the password; stalled or oversized requests are dropped.
**Cloudflare (optional, free, extra layer):** SSL/TLS > Always Use HTTPS + Minimum TLS 1.2; Security > Bot Fight Mode ON; add a Rate limiting rule for /api/* (e.g. 60 requests / 10 s per IP). If the orange cloud is on, the server detects Cloudflare automatically.
**Honest limits:** nothing is unhackable, and a visitor can always inspect their own browser. This design makes sure that cannot hurt anyone else. Keep ADMIN_KEY secret, rotate it if it ever leaks, and keep the site on HTTPS.

# v20
**A new champion every 2 days** (voting runs 47 hours, then 1 sealed hour, and the winner is announced at exactly 2 days, then a new round starts). Set `CYCLE_MIN` (minutes) to change the whole cycle length.
**Intro:** the last part only asks for the visitor's name (nominating happens inside the site). Skip jumps straight to it; "ENTER THE AXIOM" opens the site in one click; that part of the music loops until they enter.
**Nothing is wiped on updates** (needs the cloud bucket - see below):
- the server saves to the cloud within seconds and again on shutdown; on start it MERGES the cloud copy with whatever it has, so a stale, empty or briefly-unreachable server can never overwrite good data;
- an old and a new server running together during a deploy sync with each other;
- snapshots (start, shutdown, every 6 h, before restore/import) are kept in the bucket and restorable from DEV panel > DATA & BACKUP;
- a copy is also kept in the DEV's browser, with a one-click restore if the server ever comes up empty;
- DEV panel > DATA & BACKUP has TEST CONNECTION, BACK UP NOW, snapshot restore, backup file download/restore.
Check after every update: https://aacselect.onrender.com/healthz -> "version":"v20" and "cloud":"on".

# v19 - Report a bug is now a PANEL (no separate page)
"Report a bug" (small link in the footer line) opens a panel on top of the page, like the DEV panel - nothing to navigate to, so it can never say "Not Found". The old /bugs address just redirects and opens the panel.
- Category chips, title, what happened, steps (optional), contact (optional).
- PROOF is optional: drop / browse / PASTE a screenshot (JPG PNG WebP GIF, up to 25 MB) or a short video (MP4 MOV WebM, up to 50 MB; env MAX_PROOF_MB). Same pipeline as Spotlight: real-file check, upload bar, copied to your cloud bucket, restored automatically.
- Admin panel > BUG REPORTS shows the proof image/video right in the report; deleting a report deletes its proof.
- Proof files nobody attached to a report are removed after 2 hours.
CHECK THAT THE UPDATE IS LIVE: open https://aacselect.onrender.com/healthz - it must show "version":"v19". If it shows no version, Render is still running the old server.js.

# v18 - what is new
1. **Names are required.** The intro finale asks "What should we call you?" and the Enter button stays locked until a valid name is given (Skip / Esc jump to that step instead of bypassing it). The name is saved with the visitor's anonymous ID, shows up in the admin panel (LIVE NOW / RECENT) and is used as the chat name, so you always know who you are banning. Reserved names like "Dev", "Admin", "Mod" are refused.
2. **DEV badge.** Unlock the admin panel and the whole site shows it: gold frame, "DEV" chip, and every chat message you send carries a glowing DEV badge. The badge is checked on the server with your password - nobody can fake it by typing "dev".
3. **Report a bug** lives on its own page, `/bugs`, linked only from the small footer line (nothing on the home page). Reports land in the admin panel > **BUG REPORTS** (mark fixed / reopen / delete).
4. **Admin panel > DATA & BACKUP** shows whether cloud save is on and lets you download / restore a full backup file (safety net when you update).

## KEEP NOMINATIONS, CHAT & EVERYTHING ELSE ACROSS UPDATES (read this once)
The server code already saves everything to a free cloud bucket and restores it on every start - but ONLY when the `S3_*` settings exist on Render. If `https://aacselect.onrender.com/healthz` says `"cloud":"off"`, the bucket is NOT set up and every restart/update wipes the site. It must say `"cloud":"on"`.
Cloudflare R2 (free, takes 5 minutes): Cloudflare dashboard > R2 > Create bucket `aacselect` > Manage R2 API Tokens > Create token (Object Read & Write) > then on Render > Environment add: `S3_ENDPOINT` = `https://<ACCOUNT_ID>.r2.cloudflarestorage.com` | `S3_BUCKET` = `aacselect` | `S3_KEY_ID` | `S3_SECRET` | `S3_REGION` = `auto`. Redeploy, open /healthz, look for `"cloud":"on"`.

# AACSELECT v17 (unofficial fan project) — https://aacselect.onrender.com/

## Deploy (Render)
Upload everything in this folder to the TOP LEVEL of your GitHub repo (server.js, package.json, render.yaml, wrangler.jsonc, public/). Render redeploys on commit.
Render settings: Root Directory = EMPTY | Build Command = `npm install` | Start Command = `node server.js` | Health Check Path = `/healthz`.

## Environment variables (Render → your service → Environment)
| Key | What it does |
|---|---|
| `ADMIN_KEY` | Optional. The admin panel password is built in (stored only as a scrambled hash in server.js). Set this to use a different password instead. |
| `S3_ENDPOINT`, `S3_BUCKET`, `S3_KEY_ID`, `S3_SECRET`, `S3_REGION` | **Cloud bucket — this is what stops the site from being wiped.** See below. |
| `MAX_PROMO_MB` (250), `MAX_IMAGE_MB` (25) | Spotlight upload limits. |
| `PROMO_CAP_MB` | Total Spotlight storage (default 8000 MB with a bucket, 900 MB without). |
| `KEEPALIVE=0` | Turns the stay-awake ping off (it is ON by default). |

## Why everything got wiped — and the fix
Render's free plan has **no permanent disk**: every restart, redeploy or wake-up starts from an empty folder, so nominations, votes, chat and videos vanished.
v17 saves everything (Board, votes, chat, champions, bans **and** Spotlight files) to a free S3-compatible cloud bucket and restores it on every start. It also writes a dated backup copy once per day (`backups/state-YYYY-MM-DD.json`).

**Option A — Cloudflare R2 (10 GB free, you already use Cloudflare):**
1. Cloudflare dashboard → R2 Object Storage → Create bucket → name it `aacselect`.
2. R2 → Manage API tokens → Create API token → permission **Object Read & Write**, limited to the `aacselect` bucket.
3. Copy into Render: `S3_ENDPOINT` = `https://<ACCOUNT_ID>.r2.cloudflarestorage.com` (shown on the token page), `S3_BUCKET` = `aacselect`, `S3_KEY_ID` = Access Key ID, `S3_SECRET` = Secret Access Key, `S3_REGION` = `auto`.

**Option B — Backblaze B2 (10 GB free, no card needed):** create a **private** bucket, then App Keys → Add a New Application Key for that bucket.
`S3_ENDPOINT` = `https://s3.<region>.backblazeb2.com` (the "Endpoint" shown on the bucket, e.g. `s3.us-west-004.backblazeb2.com`), `S3_REGION` = the region part (e.g. `us-west-004`), `S3_KEY_ID` = keyID, `S3_SECRET` = applicationKey.

**Check it works:** open https://aacselect.onrender.com/healthz → it must say `"cloud":"on"`. The admin panel also shows a green "CLOUD SAVE ON" chip.
(Alternative without a bucket: a paid Render plan + a Disk mounted at `/data` and `DB_FILE=/data/data.json`.)

## Always on ("eternal" server)
The free plan sleeps after 15 minutes without visitors. The server now pings its own public address about every 10 minutes so it never falls asleep. For extra safety add a free monitor at uptimerobot.com (HTTP, every 5 min) on `https://aacselect.onrender.com/healthz`.
Free plan = 750 hours/month, enough for one service running 24/7. Render can still restart the server for deploys/maintenance; with the bucket set up nothing is lost.
While the server restarts, visitors now see the last known Board (marked RECONNECTING) instead of an empty one.

## v17 changes
1. **Spotlight:** videos up to **250 MB / 3 minutes** (MP4, MOV, WebM) and **images** (JPG, PNG, WebP, GIF up to 25 MB). Tap a video to turn its sound on.
2. **Nominations stay** for the whole cycle and are only cleared after the countdown ends **and a winner is announced** (if nobody voted, the Board carries over to the next cycle).
3. **Nominating someone already on the Board = a nod** from you (matched by handle/link or by name, so `@Nova`, `tiktok.com/@nova` and "Nova" all count for the same creator). One nod per person per cycle.
4. Address everywhere is now **aacselect.onrender.com**.
5. Stay-awake ping + cloud saving (above).
6. **Hidden admin panel — AXIOM CONTROL.**

## AXIOM CONTROL (developer only)
**Open it:** scroll to the very bottom of the site and **double-click (or double-tap on a phone) the AAC badge in the footer**. It asks for the developer password; the correct password opens the Admin Panel. Wrong passwords are refused, and 6 wrong tries lock that network out for 10 minutes. The password is case-sensitive. To change it, set `ADMIN_KEY` on Render.
- **LIVE NOW:** everyone on the site right now: name (if they chatted), short visitor ID, device/browser, network tag, time connected, tabs, actions. **KICK** (disconnects them, they can rejoin after 15 s) or **BAN**.
- **Ban bar:** ban anyone, even if they're not on the site — type a **visitor ID**, a **chat name**, or an **IP address**. A name nobody has used yet becomes a waiting ban: whoever chats with that name is banned instantly.
- **How long:** 10 min, 1 hour, 1 day, 7 days, 30 days, forever, or any exact number of minutes/hours/days, plus a reason (shown to them). "Also block their network" stops them coming back in a new browser/private window (note: it also blocks others on that same Wi-Fi).
- Banned visitors get a full-screen animated **BANNED** screen with the reason and a live countdown; it lifts by itself when the time is up, or instantly when you press **UNBAN** in the **BANS** tab.
- **RECENT VISITORS** (last 45 days) and **BOARD · SPOTLIGHT · CHAT** (remove a creator, delete a Spotlight post, clear chat).

## Earlier notes
- Axiom Guard v2 word lists: `GD_WORD` / `GD_STRONG` in server.js and the "AXIOM GUARD v2" block in `public/assets/index-v17.js`.
- `CYCLE_MIN=2` makes a whole cycle last 2 minutes (testing only).
